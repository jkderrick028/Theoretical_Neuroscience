# Computational-Neuroscience-UW-Coursera
Programming assignments for the MOOC Computational Neuroscience by University of Washington on Coursera (https://www.coursera.org/learn/computational-neuroscience)
