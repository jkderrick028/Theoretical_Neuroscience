## Overview: 

What will be discussed?
- Techniques for recording from the brain.
- Tools for discovering how the brain represents information.
- Models that express out understanding of this representation.
- Some methods for inferring what the brain is doing based upon it's activity (Week-3).
- Using Information Theory to quantify neural representation (Week-4).
- The Bio-Physical basis of how the brain processes inputs and performs complex computations (Week-5).
