These are incomplete codes that were shared in the quiz. I've edited only few lines.
