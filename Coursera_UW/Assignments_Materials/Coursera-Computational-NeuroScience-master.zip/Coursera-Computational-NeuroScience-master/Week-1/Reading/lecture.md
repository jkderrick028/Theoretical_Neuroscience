Lecture notes for week 1 --- <a href="https://d396qusza40orc.cloudfront.net/compneuro/supplementary/Week%201%20Lecture%20Notes.pdf">click here</a>
