```
CNS Central Nervous System (Lecture 1-6, 3:23)

CPU Central Processing Unit (Lecture 1-6, 15:03)

EPSP Excitatory Post-Synaptic Potential (Lecture 1-4, 4:28; Lecture 1-5, 8:30)

GABA gamma-aminobutyric acid, C4H9NO2, a neurotransmitter (Lecture 1-5, 10:07)

GABAB GABA-B metabotropic receptors that use G-protein intermediaries to open/close K+ ion channels (Lecture 1-5, 10:24; Wikipedia)

ICA Independent Component Analysis (Bell and Sejnowski, 1997) (Lecture 1-3, 9:45)

IPSP Inhibitory Post-Synaptic Potential (Lecture 1-5, 9:47)

LGN Lateral Geniculate Nucleus (Lecture 1-2, 8:50)

LTD Long-Term Depression (Lecture 1-5, 16:22)

LTP Long-Term Potentiation (Lecture 1-5, 14:45)

RF Receptive Field (Lecture 1-3, 1:28)

PNS Peripheral Nervous System (Lecture 1-6, 0:35)

STDP Spike-Timing Dependent Plasticity (Lecture 1-5, 19:25)

V1 Primary Visual Cortex (Lecture 1-2, 9:04)
```
