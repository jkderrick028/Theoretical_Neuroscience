```m
>> x=0:0.05:5;y=sin(x.^2);plot(x,y);
```
![](http://geekresearchlab.net/coursera/neuro/figure-1_.jpg)
