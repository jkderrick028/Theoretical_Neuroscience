<b>Score:</b> 14/14
