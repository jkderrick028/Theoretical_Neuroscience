Only for my future reference... Not for the purpose to share solutions with anyone..
