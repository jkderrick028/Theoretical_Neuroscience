NeuroBiology-101 consists of the portions that will discuss about the Neurons, Synapses and Brain regions.
