Conclusions and Summary:
```
The structure and organization of the brain suggests computational analogies such as:
(i) Information storage:
Physical/Chemical structure of neurons and synapses.
(ii) Information transmission:
Electrical and Chemical Signalling.
(iii) Primary computing elements:- Neurons
(iv) Computational basis:- currently unknown.
```
