![](http://geekresearchlab.net/coursera/neuro/1-1-outline.jpg)
<br><br>
![](http://geekresearchlab.net/coursera/neuro/1-2-goals.jpg)
