# Computational-NeuroScience
Computational NeuroScience is a rigorous 8-week course in Coursera from University of Washington that focus on basic computational techniques for analyzing, modelling and understanding the behaviour of cells and circuits in the brain.
