![](http://geekresearchlab.net/coursera/neuro/ul-1.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-2.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-3.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-4.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-5.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-6.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-7.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-8.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-9.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-10.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-11.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-12.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-13.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-14.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-15.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-16.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/ul-17.jpg)
```
100X100 has how many dimensions? It's 10000.
Explanation:- (that lecture didn't provide proper explanation)
Imagine a matrix... :) 
Every matrix is the form of rowsXcolumns or heightXwidth
1X1 matrix => 1^2 => 1 dimension
100X100 matrix => 100^2 => 10000 dimensions
Graph is in the form of matrix x-y axis...
Simulation relays on matrix plots & values are found based on it or sometimes other math methods.
Everything is matrix..
```
