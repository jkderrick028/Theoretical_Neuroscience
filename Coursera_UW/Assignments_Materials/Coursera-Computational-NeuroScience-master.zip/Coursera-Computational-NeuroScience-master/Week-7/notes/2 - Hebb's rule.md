![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-1.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-2.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-3.jpg)
