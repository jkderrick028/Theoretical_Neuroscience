![](http://geekresearchlab.net/coursera/neuro/xx/ls-3-2.jpg)
