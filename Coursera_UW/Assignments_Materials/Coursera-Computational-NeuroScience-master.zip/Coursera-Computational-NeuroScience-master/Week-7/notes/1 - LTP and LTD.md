![](http://geekresearchlab.net/coursera/neuro/xx/ls-1-1.jpg)



![](http://geekresearchlab.net/coursera/neuro/xx/ls-1-2.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-1-3.jpg)