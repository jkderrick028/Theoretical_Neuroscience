![](http://geekresearchlab.net/coursera/neuro/xx/ls-3-1.jpg)
