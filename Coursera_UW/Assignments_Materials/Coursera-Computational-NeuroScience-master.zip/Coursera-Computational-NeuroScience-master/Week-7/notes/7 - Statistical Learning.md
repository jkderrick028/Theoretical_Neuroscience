![](http://geekresearchlab.net/coursera/neuro/xx/ls-4-1.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-4-2.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-4-3.jpg)
