![](http://geekresearchlab.net/coursera/neuro/xx/ls-3-3.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-3-5.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-3-4.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-3-4-1.jpg)<br>
