![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-4.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-5.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-6.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-7.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/xx/ls-2-8.jpg)<br><br>
