![](http://geekresearchlab.net/coursera/neuro/spik-1.jpg)
