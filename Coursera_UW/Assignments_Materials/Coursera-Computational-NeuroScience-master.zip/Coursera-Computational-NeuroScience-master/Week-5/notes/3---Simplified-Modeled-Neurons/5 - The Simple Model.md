![](http://geekresearchlab.net/coursera/neuro/spik-10.jpg)<br><br>
![](http://geekresearchlab.net/coursera/neuro/spik-10-1.jpg)<br>
