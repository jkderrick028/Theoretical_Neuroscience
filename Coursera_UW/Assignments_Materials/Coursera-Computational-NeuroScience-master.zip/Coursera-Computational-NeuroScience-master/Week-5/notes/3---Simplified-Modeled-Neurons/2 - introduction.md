![](http://geekresearchlab.net/coursera/neuro/spik-2.jpg)
